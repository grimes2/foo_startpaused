#define _WIN32_WINNT _WIN32_WINNT_WIN7
#define WINVER _WIN32_WINNT_WIN7

#include <vector>
#include <concurrent_unordered_map.h>
#include <concurrent_vector.h>
#include <helpers/foobar2000+atl.h>
#include <libPPUI/CListControlSimple.h>
#include <SDK/coreDarkMode.h>

#include "resource.hpp"

#pragma comment(lib, "shlwapi.lib")


	static constexpr const char* component_name = "Stop after album";

	DECLARE_COMPONENT_VERSION(
		component_name,
		"1.0",
		"grimes\n\n"
		"Build: " __TIME__ ", " __DATE__
	);

	VALIDATE_COMPONENT_FILENAME("foo_playlist_fix.dll");

	static constexpr GUID g_guid_main_menu_group = { 0x7d498416, 0xca19, 0x40a3, { 0xa5, 0x16, 0x24, 0xe3, 0x5, 0xcc, 0x15, 0x8c } };


	// {42E2EBA7-F0CA-43b6-AAF5-13509598CFB4}
	static constexpr GUID g_guid_main_stopafteralbum_toggle = { 0x42e2eba7, 0xf0ca, 0x43b6, { 0xaa, 0xf5, 0x13, 0x50, 0x95, 0x98, 0xcf, 0xb4 } };

	bool cfg_menu_stopalbum_enabled = false;
	pfc::string8 tag1;
	pfc::string8 tag2;
	pfc::string8 tracknumber;
	int tracknumber2;
	pfc::string8 totaltracks;
	int totaltracks2;

	struct ReportItem
	{
		size_t playlistItemIndex{};
		pfc::string8 playlistName, deadPath, newPath;
	};

	std::vector<ReportItem> g_report_items;

	struct MenuItem
	{
		const GUID* guid;
		const pfc::string8 name, desc;
	};

	const std::vector<MenuItem> g_menu_items =
	{
		{ &g_guid_main_stopafteralbum_toggle, "Stop after album", "Toggles stop after album." },
	};

	bool is_checked(t_uint32 p_index)
	{
		if (p_index == 0)
			return cfg_menu_stopalbum_enabled;
	}

	class MainMenu : public mainmenu_commands
	{
	public:
	
		void execute(t_uint32 p_index, service_ptr_t<service_base> p_callback) override {
				cfg_menu_stopalbum_enabled = !cfg_menu_stopalbum_enabled;
				if (cfg_menu_stopalbum_enabled)
				{
					cfg_menu_stopalbum_enabled = true;
					static_api_ptr_t<playback_control>()->set_stop_after_current(false);
					if ((totaltracks2 == tracknumber2) && (static_api_ptr_t<playback_control>()->is_paused() || static_api_ptr_t<playback_control>()->is_playing()))
					{
						static_api_ptr_t<playback_control>()->set_stop_after_current(true);
						console::info("Stop after current (album)");
					}
					else
					{
						console::info("Stop after album");
					}
				}
				else
				{
					static_api_ptr_t<playback_control>()->set_stop_after_current(false);
				}
			}
	};

	static mainmenu_group_popup_factory g_main_menu_group(g_guid_main_menu_group, mainmenu_groups::file, mainmenu_commands::sort_priority_base, component_name);
	FB2K_SERVICE_FACTORY(MainMenu);

	class play_callback_stopafteralbum : public play_callback_static
	{

	public:
		virtual unsigned get_flags(void)
		{
			return(flag_on_playback_new_track | flag_on_playback_stop);
		}

		virtual void FB2KAPI on_playback_new_track(metadb_handle_ptr p_track)
		{
			p_track->metadb_lock();
			titleformat_object::ptr tagobj1;
			titleformat_object::ptr tagobj2;
			static_api_ptr_t<titleformat_compiler> compiler;
			tag1 = "%tracknumber%";
			compiler->compile(tagobj1, tag1);
			tag2 = "%totaltracks%";
			compiler->compile(tagobj2, tag2);
			p_track->format_title(NULL, tracknumber, tagobj1, NULL);
			p_track->format_title(NULL, totaltracks, tagobj2, NULL);
			tagobj1.release();
			tagobj2.release();
			p_track->metadb_unlock();
			SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(tracknumber));
			SysAllocString(pfc::stringcvt::string_wide_from_utf8_fast(totaltracks));
		}

};

